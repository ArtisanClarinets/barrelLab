import streamlit as st
import plotly.graph_objects as go
import numpy as np
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG, filename="bore_editor.log", filemode="w",
                    format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger()

st.subheader("2D Bore Cross-Section Editor")

# Placeholder draggable control points
if "control_points" not in st.session_state:
    st.session_state.control_points = [(0, 10), (30, 8), (60, 10)]
logger.debug(f"Initial control points: {st.session_state.control_points}")

edited = False
x_vals, y_vals = zip(*st.session_state.control_points)

fig = go.Figure()
fig.add_trace(go.Scatter(x=x_vals, y=y_vals, mode='markers+lines', name="Bore Profile"))

fig.update_layout(
    dragmode='drawopenpath',
    title="Drag points to edit bore profile",
    xaxis_title="Length (mm)",
    yaxis_title="Radius (mm)",
    height=400
)

plot = st.plotly_chart(fig, use_container_width=True)

# For future: capture edited path using custom JavaScript or draw plugin (streamlit-drawable-canvas)
st.warning("⚠️ Dragging not yet updates state. Future versions will include interactive updates.")
