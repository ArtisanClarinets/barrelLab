# gpu_compute.py
import cupy as cp
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def gpu_accelerated_impedance(lengths, radii):
    logger.info("Running GPU impedance computation...")
    try:
        z = cp.array(lengths) * cp.array(radii)
        result = cp.sum(z)
        logger.info("GPU computation successful.")
        return result.get()
    except Exception as e:
        logger.error(f"GPU error: {e}")
        return None
