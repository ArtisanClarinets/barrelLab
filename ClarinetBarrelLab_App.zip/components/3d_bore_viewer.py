import streamlit as st
import pyvista as pv
from pyvista import themes
import numpy as np
import logging
import tempfile
import os

# Setup logging
logging.basicConfig(level=logging.DEBUG, filename="3d_bore_viewer.log", filemode="w",
                    format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger()

st.subheader("3D Bore Viewer")

# Setup PyVista and Panel interop
pv.set_plot_theme(themes.DocumentTheme())

# Generate synthetic bore profile
def generate_bore(length_mm=60, radius_profile=[10, 8, 10], n_samples=100):
    z = np.linspace(0, length_mm, n_samples)
    r = np.interp(z, [0, length_mm//2, length_mm], radius_profile)
    logger.debug(f"Bore Z: {z}")
    logger.debug(f"Bore Radius: {r}")
    return z, r

def create_bore_mesh(z, r):
    points = []
    for zi, ri in zip(z, r):
        theta = np.linspace(0, 2*np.pi, 36)
        x = ri * np.cos(theta)
        y = ri * np.sin(theta)
        for xi, yi in zip(x, y):
            points.append([xi, yi, zi])
    points = np.array(points)
    mesh = pv.PolyData(points)
    mesh = mesh.delaunay_2d()
    logger.info("3D mesh generated successfully.")
    return mesh

z, r = generate_bore()
bore_mesh = create_bore_mesh(z, r)

# Show the 3D model
plotter = pv.Plotter(off_screen=True, notebook=False)
plotter.add_mesh(bore_mesh, color="tan", opacity=0.8)
plotter.add_axes()
plotter.view_xy()

# Save to temporary file and display
with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmpfile:
    plotter.show(screenshot=tmpfile.name)
    st.image(tmpfile.name, caption="3D Bore Preview")
    logger.info(f"3D bore preview saved to: {tmpfile.name}")
    os.unlink(tmpfile.name)
